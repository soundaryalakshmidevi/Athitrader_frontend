import React, { useState, useEffect } from 'react';
import Axios from "../Axios";
import '../Employee.css'; // Assuming you have a CSS file for styling
import Sidebar from './Sidebar';
import { DownOutlined } from '@ant-design/icons'; 
import { IconButton } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit'; 
import DeleteIcon from '@mui/icons-material/Delete'; 
import { Dialog, DialogActions, DialogContent, DialogTitle, Button } from '@mui/material';
import { SearchOutlined } from '@mui/icons-material';
import AddIcon from '@mui/icons-material/Add';
import '../loandue.css';

const Loandue = (initialGroupedLoans) => {
    const [loans, setLoans] = useState([]);
    const [employees, setEmployees] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState(null);
    const [expandedLoanId, setExpandedLoanId] = useState(null);
    const [formData, setFormData] = useState({
        loan_id: '',
        user_id: '',
        due_amount: '',
        due_date: '',
        paid_on: '',
        collection_by: '',
    });
    const [filterLoanId, setFilterLoanId] = useState('');
    const [LoansGroup, setLoansGroup] = useState(initialGroupedLoans);
    
    const filteredEmployees = (employees ?? []).filter(employee =>
        employee.loan_id?.toString().includes(filterLoanId)
    );

    useEffect(() => {
        const userId = localStorage.getItem('user_id'); // Assuming userId is stored in localStorage
        if (userId) {
            setFormData((prevData) => ({
                ...prevData,
                collection_by: userId, // Set reference user ID from LocalStorage
            }));
        }
    }, []);
    const fetchEmployees = async () => {
        try {
            const response = await Axios.get('/loan-due-index');
            const employeeData = response.data.data; // Assuming this is the correct path to your data
            console.log("Fetched Employees: ", employeeData); // Log the response data
            setEmployees(employeeData);  // Set employees data
        } catch (error) {
            console.error('Error fetching loan data:', error.message);
        }
    };
    
    
    useEffect(() => {
        console.log("Employees: ", employees); // Log employees after setting them
        fetchEmployees();
    }, []);
    

    const fetchLoan = async () => {
        try {
            const response = await Axios.get('/loan');
            setLoans(response.data.loans); // Store the fetched loans
        } catch (error) {
            alert('Error fetching loan: ' + error.message);
        }
    };

    useEffect(() => {
        fetchLoan();
    }, []);

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this loan due?')) {
            try {
                await Axios.delete(`loan-due/${id}`);
                setEmployees(employees.filter(employee => employee.id !== id));
                alert('Loan due deleted successfully!');
            } catch (error) {
                alert('Error deleting loan due: ' + error.message);
            }
        }
    };

    const handleEdit = (employee) => {
        setEditingEmployee(employee);
        setFormData({
            loan_id: employee.loan_id,
            user_id: employee.user_id,
            due_amount: employee.due_amount,
            due_date: employee.due_date,
            paid_on: employee.paid_on,
            collection_by: employee.collection_by,
        });
        setShowForm(true);
    };

    const handleAdd = () => {
        setEditingEmployee(null);
        setFormData({
            loan_id: '',
            user_id: '',
            due_amount: '',
            due_date: '',
            paid_on: '',
            collection_by: '',
        });
        setShowForm(true);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleInputChange = (employeeId, employee, field, value) => {
        const updatedEmployee = {
            ...employee,
            [field]: value,
        };

        const paidAmount = parseFloat(updatedEmployee.paid_amount) || 0;
        const dueAmount = parseFloat(updatedEmployee.due_amount) || 0;

        if (paidAmount === dueAmount) {
            updatedEmployee.status = "paid";
        } else if (paidAmount < dueAmount) {
            updatedEmployee.status = "pending";
        } else {
            updatedEmployee.status = "unpaid";
        }

        setEmployees((prevEmployees) =>
            prevEmployees.map((emp) =>
                emp.id === employeeId ? updatedEmployee : emp
            )
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editingEmployee) {
                await Axios.put(`/loan-due/${editingEmployee.id}`, formData);
                alert('Loan due updated successfully!');
            } else {
                await Axios.post('/loan-due', formData);
                alert('Loan due added successfully!');
            }
            setShowForm(false);
            fetchEmployees();
        } catch (error) {
            alert('Error saving Loan due: ' + error.message);
        }
    };

    const handleToggleExpand = (id) => {
        setExpandedLoanId(expandedLoanId === id ? null : id);
    };

    function groupLoansById(employees) {
        return employees.reduce((groups, employee) => {
            const { loan_id } = employee;
            if (!groups[loan_id]) {
                groups[loan_id] = [];
            }
            groups[loan_id].push(employee);
            return groups;
        }, {});
    }
    
    const groupedLoans = groupLoansById(filteredEmployees);

    return (
        <div className="container">
            <Sidebar className="sidebar" />
            <div className="main-content">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <button className="small-button" onClick={handleAdd}>Add Loan Due</button>
                    <div style={{ display: 'flex', alignItems: 'center', marginLeft: '10px' }}>
                        <input
                            type="text"
                            value={filterLoanId}
                            onChange={(e) => setFilterLoanId(e.target.value)}
                            placeholder="Enter Loan ID"
                            style={{ padding: '5px 10px', marginRight: '10px' }}
                        />
                        <SearchOutlined style={{ fontSize: '24px', cursor: 'pointer' }} />
                    </div>
                </div>

                <div className="table-container">
                    {Object.keys(groupedLoans).length > 0 ? (
                        Object.keys(groupedLoans).map(loanId => (
                            <div key={loanId} className="loan-group">
                                <div 
                                    className="loan-header" 
                                    onClick={() => handleToggleExpand(loanId)} 
                                    style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', justifyContent: 'space-between' }}
                                >
                                    <h4 style={{ margin: 0 }}>Loan ID: {loanId}</h4>
                                    <span 
                                    className={`expand-icon ${expandedLoanId === loanId ? 'rotate' : ''}`} 
                                    style={{ marginLeft: '8px', color: 'white' }}
                                    >
                                    <DownOutlined />
                                    </span>

                                </div>

                                {expandedLoanId === loanId && (
                                    <table className="loan-table">
                                        <thead>
                                            <tr>
                                                <th>Loan ID</th>
                                                <th>User ID</th>
                                                <th>Due Amount</th>
                                                <th>Paid Amount</th>
                                                <th>Status</th>
                                                <th>Due Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {groupedLoans[loanId].map(employee => (
                                                <tr key={employee.id}>
                                                    <td>{employee.loan_id}</td>
                                                    <td>{employee.user_id}</td>
                                                    <td>
                                                        <input
                                                            type="number"
                                                            value={employee.due_amount}
                                                            onChange={(e) => handleInputChange(employee.id, employee, 'due_amount', e.target.value)}
                                                        />
                                                    </td>
                                                    <td>
                                                        <input
                                                            type="number"
                                                            value={employee.paid_amount}
                                                            onChange={(e) => handleInputChange(employee.id, employee, 'paid_amount', e.target.value)}
                                                        />
                                                    </td>
                                                    <td>{employee.status}</td>
                                                    <td>{employee.due_date}</td>
                                                    <td>
                                                        <IconButton onClick={() => handleEdit(employee)}>
                                                            <EditIcon />
                                                        </IconButton>
                                                        <IconButton onClick={() => handleDelete(employee.id)}>
                                                            <DeleteIcon />
                                                        </IconButton>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                )}
                            </div>
                        ))
                    ) : (
                        <p>No loans found</p>
                    )}
                </div>

                <Dialog open={showForm} onClose={() => setShowForm(false)}>
                    <DialogTitle>{editingEmployee ? 'Edit Loan Due' : 'Add Loan Due'}</DialogTitle>
                    <DialogContent>
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label>Loan ID:</label>
                                <input
                                    type="text"
                                    name="loan_id"
                                    value={formData.loan_id}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>User ID:</label>
                                <input
                                    type="text"
                                    name="user_id"
                                    value={formData.user_id}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Due Amount:</label>
                                <input
                                    type="number"
                                    name="due_amount"
                                    value={formData.due_amount}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Due Date:</label>
                                <input
                                    type="date"
                                    name="due_date"
                                    value={formData.due_date}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label>Paid On:</label>
                                <input
                                    type="date"
                                    name="paid_on"
                                    value={formData.paid_on}
                                    onChange={handleChange}
                                />
                            </div>
                            <div className="form-group">
                                <label>Collection By:</label>
                                <input
                                    type="text"
                                    name="collection_by"
                                    value={formData.collection_by}
                                    onChange={handleChange}
                                    readOnly
                                />
                            </div>
                        </form>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setShowForm(false)} color="primary">
                            Cancel
                        </Button>
                        <Button onClick={handleSubmit} color="primary">
                            {editingEmployee ? 'Update' : 'Add'}
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        </div>
    );
};

export default Loandue;
