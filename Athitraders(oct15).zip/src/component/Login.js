import React, { useState } from 'react';
import Axios from "../Axios";
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import logoImage from '../asset/ATHI_TRADERS_LOGO.jpg'; 
import '../Login.css';
import { MdArrowForward } from 'react-icons/md';
import Spinner from '../Spinner.js'; 
import backgroundimage from '../asset/AT background.png'; // Import background image

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false); 
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
    
        try {
            // Check if the input is an email or user ID (assuming emails contain '@')
            const loginData = {
                email: email.includes('@') ? email : undefined,
                user_id: !email.includes('@') ? email : undefined,
                password: password,
            };
    
            // Attempt login
            const response = await Axios.post('/login', loginData);
    
            // Store token and user_id in localStorage
            localStorage.setItem('token', response.data.token);
            localStorage.setItem('user_id', response.data.user_id);
    
            // Check if token is successfully set
            const token = localStorage.getItem('token');
            const userId = localStorage.getItem('user_id');
            
            if (token && userId) {
                // Fetch user profile
                try {
                    const loggedInUserId = localStorage.getItem('user_id');
                    const profileResponse = await Axios.get(`/profile/${loggedInUserId}`);
                    const userProfileData = profileResponse.data.message;
    
                    if (userProfileData) {
                        console.log("User profile data:", userProfileData);
                        // Optionally set additional profile data in localStorage
                        // localStorage.setItem('ref_name', userProfileData.user_name);
                        // localStorage.setItem('ref_aadhar_number', userProfileData.aadhar_number);
                    }
                } catch (err) {
                    console.error("Error occurred while fetching user profile", err);
                }
    
                // Navigate based on user role
                if (response.data.role === 'admin') {
                    navigate('/admindashboard');
                } else {
                    navigate('/dashboard');
                }
            } else {
                // Token is not set, show error
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed',
                    text: 'Login was not successful. Please try again.',
                });
            }
        } catch (error) {
            console.error('Login Error:', error);
            if (error.response) {
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed',
                    text: error.response.data.error || 'An error occurred during login.',
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed',
                    text: 'An unexpected error occurred.',
                });
            }
        } finally {
            setLoading(false);
        }
    };
    
    console.log(backgroundimage); // Add this line to check the URL


    return (
        <div
        className="container1"
        style={{
            height: '100vh',
            width: '100vw',
            backgroundImage: `url(${backgroundimage})`, // Set the background image here
            
            backgroundSize: 'cover', // Cover the full container
            backgroundPosition: 'center', // Center the background image
            backgroundRepeat: 'no-repeat', // Prevent repeating
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            flexDirection: 'column',
        }}
    >
            <div className="login-container">
                <img src={logoImage} alt="Athi Traders Logo" className="logo1" />
                <h2>Sign In</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group-login">
                        <label htmlFor="email">Employee Id</label>
                        <input
                          
                            id="email"
                            name="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            autoComplete="email"
                        />
                    </div>
                    <div className="form-group-login">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            autoComplete="current-password"
                        />
                    </div>

                    <div className="forgot-password-login">
                        <a href="/forgot-password">Forgot Password?</a>
                    </div>

                    <button type="submit" disabled={loading}> {/* Disable button when loading */}
                        {loading ? <Spinner /> : <>Sign in <MdArrowForward /></>} {/* Show spinner or text */}
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Login;
