import React, { useEffect, useState } from 'react';
import { Table, TableHead, TableRow, TableCell, TableBody, Paper, Typography, CircularProgress, Box } from '@mui/material';
import Sidebar from './Sidebar'; // Ensure the path is correct
import Axios from "../Axios";

const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSidebarExpanded, setSidebarExpanded] = useState(true); // Add this state

  // Fetch transactions data
  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await Axios.get('/alltransaction');
        if (response.data.success) {
          setTransactions(response.data.data);
        } else {
          setError(response.data.message);
        }
      } catch (error) {
        setError('Failed to fetch transactions.');
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  return (
    <div className="main-content">
      <Box sx={{ display: 'block' }}>
        <Sidebar isSidebarExpanded={isSidebarExpanded} setSidebarExpanded={setSidebarExpanded} /> {/* Pass down the prop */}
        <Box
  component={Paper}
  sx={{
    flexGrow: 1,
    padding: 3,
    marginLeft: isSidebarExpanded ? '240px' : '60px', // Adjusted to match your sidebar width
    overflow: 'auto', // Ensure it can scroll if content overflows
    height: '100vh', // Make sure it takes full height
  }}
>

          <Typography variant="h5" gutterBottom>
            Transactions
          </Typography>

          {loading ? (
            <Box display="flex" justifyContent="center" alignItems="center" height={200}>
              <CircularProgress />
            </Box>
          ) : error ? (
            <Typography color="error">{error}</Typography>
          ) : (
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>ID</TableCell>
                  <TableCell>Loan ID</TableCell>
                  <TableCell>User ID</TableCell>
                  <TableCell>Employee ID</TableCell>
                  <TableCell>Category ID</TableCell>
                  <TableCell>Loan Amount</TableCell>
                  <TableCell>Loan Category</TableCell>
                  <TableCell>Loan Date</TableCell>
                  <TableCell>Total Amount</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Loan Closed Date</TableCell>
                  <TableCell>Payment Status</TableCell>
                  <TableCell>Created At</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{transaction.id}</TableCell>
                    <TableCell>{transaction.loan_id}</TableCell>
                    <TableCell>{transaction.user_id}</TableCell>
                    <TableCell>{transaction.employee_id}</TableCell>
                    <TableCell>{transaction.category_id}</TableCell>
                    <TableCell>{transaction.loan_amount}</TableCell>
                    <TableCell>{transaction.loan_category}</TableCell>
                    <TableCell>{transaction.loan_date}</TableCell>
                    <TableCell>{transaction.total_amount}</TableCell>
                    <TableCell>{transaction.status}</TableCell>
                    <TableCell>{transaction.loan_closed_date}</TableCell>
                    <TableCell>{transaction.payment_status}</TableCell>
                    <TableCell>{new Date(transaction.created_at).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Box>
      </Box>
    </div>
  );
};

export default Transactions;
