import React, { useState, useEffect } from 'react';
import Axios from "../Axios";
import '../Employee.css'; // Assuming you have a CSS file for styling
import Sidebar from './Sidebar';
import { DownOutlined } from '@ant-design/icons'; 
import { IconButton } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit'; 
import DeleteIcon from '@mui/icons-material/Delete'; 
import { Dialog, DialogActions, DialogContent, DialogTitle, Button,TextField } from '@mui/material';
import { SearchOutlined } from '@mui/icons-material';
import AddIcon from '@mui/icons-material/Add';
import '../loandue.css';
import VisibilityIcon from '@mui/icons-material/Visibility'; // Import the eye icon
import * as XLSX from 'xlsx'; // Import xlsx
import { saveAs } from 'file-saver'; // Import file-saver
import DownloadIcon from '@mui/icons-material/GetApp';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import { useLocation } from 'react-router-dom'; 
const Loandue = (initialGroupedLoans) => {
    const [loans, setLoans] = useState([]);
    const [employees, setEmployees] = useState([]);
    const [showForm, setShowForm] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState(null);
    const [expandedLoanId, setExpandedLoanId] = useState(null);
    const [formData, setFormData] = useState({
        loan_id: '',
        user_id: '',
        due_amount: '',
        due_date: '',
        paid_on: '',
        paid_amount: '',
        collection_by: '',
        // future_date:'',
    });
 

    const [filterLoanId, setFilterLoanId] = useState('');
    const [LoansGroup, setLoansGroup] = useState(initialGroupedLoans);
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const filteredEmployees = (employees ?? []).filter(employee =>
        employee.loan_id?.toString().includes(filterLoanId)
    );
    const [currentDate, setCurrentDate] = useState('');
    const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const [successMessage, setSuccessMessage] = useState('');
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [isSidebarExpanded, setSidebarExpanded] = useState(true);
  const location = useLocation(); 
    const handleSnackbarClose = (event, reason) => {
        if (reason === 'clickaway') {
          return;
        }
        setSnackbarOpen(false);
      };

      useEffect(() => {
        // Check if loanId is passed from the previous page
        if (location.state && location.state.loanId) {
            setExpandedLoanId(location.state.loanId);
        }
    }, [location.state]);

    useEffect(() => {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        const day = String(today.getDate()).padStart(2, '0');
        setCurrentDate(`${year}-${month}-${day}`);  // Set the current date
    }, []);

    
    useEffect(() => {
        if (showForm) {
            const userId = localStorage.getItem('user_id'); // Fetch user ID from localStorage
            // Set the Collection By field with the fetched user ID
            setSelectedEmployee((prev) => ({
                ...prev,
                collection_by: userId || '', // Default to empty if userId is null
            }));
        }
    }, [showForm, setSelectedEmployee]);
    
    const fetchEmployees = async () => {
        try {
            const response = await Axios.get('/loan-due-index');
            const employeeData = response.data.data; // Assuming this is the correct path to your data
            console.log("Fetched Employees: ", employeeData); // Log the response data
            setEmployees(employeeData);  // Set employees data
        } catch (error) {
            console.error('Error fetching loan data:', error.message);
        }
    };
    
    
    useEffect(() => {
        console.log("Employees: ", employees); // Log employees after setting them
        fetchEmployees();
    }, []);
    

    const fetchLoan = async () => {
        try {
            const response = await Axios.get('/loan');
            setLoans(response.data.loans); // Store the fetched loans
        } catch (error) {
            // alert('Error fetching loan: ' + error.message);
        }
    };

    useEffect(() => {
        fetchLoan();
    }, []);

    const handleview= async (id) => {
        
    };

    const handleEdit = (employee) => {
        const userId = localStorage.getItem('user_id'); 
        setEditingEmployee(employee);
        setFormData({
            loan_id: employee.loan_id,
            user_id: employee.user_id,
            due_amount: employee.next_amount  !== null ? employee.next_amount : employee.due_amount,
            paid_amount:employee.paid_amount,
            due_date: employee.due_date,
            // future_date: employee.future_date,
            paid_on: employee.paid_on || new Date().toISOString().split('T')[0],
            collection_by: userId || employee.collection_by,
        });
        setShowForm(true);
    };

    const handleAdd = () => {
        setEditingEmployee(null);
        setFormData({
            loan_id: '',
            user_id: '',
            due_amount: '',
            paid_amount:'',
            due_date: '',
            paid_on: '',
            collection_by: '',
            // future_date: '',
        });
        setShowForm(true);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleInputChange = (employeeId, employee, field, value) => {
        const updatedEmployee = {
            ...employee,
            [field]: value,
        };

        const paidAmount = parseFloat(updatedEmployee.paid_amount) || 0;
        const dueAmount = parseFloat(updatedEmployee.due_amount) || 0;

        if (paidAmount === dueAmount) {
            updatedEmployee.status = "paid";
        } else if (paidAmount < dueAmount) {
            updatedEmployee.status = "pending";
        } else {
            updatedEmployee.status = "unpaid";
        }

        setEmployees((prevEmployees) =>
            prevEmployees.map((emp) =>
                emp.id === employeeId ? updatedEmployee : emp
            )
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const { loan_id, ...otherData } = formData;
    
        // Optional: Validate if the due date is in the future
        const currentDate = new Date();
        const selectedDueDate = new Date(formData.due_date);
    
        // if (selectedDueDate <= currentDate) {
        //     alert('Due date must be a future date.');
        //     return; // Stop form submission if due date is not valid
        // }
    
        try {
            if (editingEmployee) {
                // If editing, attempt to update the loan due
                await Axios.put(`/update-future-date/${loan_id}`, formData);
                setSuccessMessage('Loan due updated successfully!');
                setSnackbarOpen(true);
            } else {
                // If not editing, create a new loan due
                await Axios.post('/loan-due', formData);
                setSuccessMessage('Loan due updated successfully!');
      setSnackbarOpen(true);
            }
    
            // Close the form and refresh the data
            setShowForm(false);
            fetchEmployees(); // Refresh the data to reflect changes
        } catch (error) {
            // Check if the error is a 404 (Loan not found or unpaid record missing)
            if (error.response && error.response.status === 404) {
                alert('First work on unpaid record');
            } else {
                // Handle any other errors
                alert('Error saving Loan due: ' + error.message);
            }
        }
    };
    
    
    
    

    const handleToggleExpand = (id) => {
        setExpandedLoanId(expandedLoanId === id ? null : id);
    };

    function groupLoansById(employees) {
        return employees.reduce((groups, employee) => {
            const { loan_id, due_date, status } = employee;
    
            if (!groups[loan_id]) {
                groups[loan_id] = { employees: [], lastDueDate: new Date(due_date), status };
            }
    
            // Add employee to the group
            groups[loan_id].employees.push(employee);
    
            // Update the last due date
            if (new Date(due_date) > groups[loan_id].lastDueDate) {
                groups[loan_id].lastDueDate = new Date(due_date);
            }
    
            return groups;
        }, {});
    }
    
    // function groupLoansById(employees) {
    //     return employees.reduce((groups, employee) => {
    //         const { loan_id } = employee;
    //         if (!groups[loan_id]) {
    //             groups[loan_id] = [];
    //         }
    //         groups[loan_id].push(employee);

            
    //         return groups;
    //     }, {});
    // }
    
    const groupedLoans = groupLoansById(filteredEmployees);


    const handleDownload = async (loanId) => {
        try {
            console.log('Fetching data for loan ID:', loanId); // Log the loan ID
            const response = await Axios.get(`/loan/${loanId}/dues`);
            console.log('API Response:', response.data); // Log the response to check data structure
    
            const loanData = response.data.loan_dues.map((loan) => ({
                LoanId: loan.loan_id,
                UserID: loan.user_id,
                DueAmount: loan.due_amount,
                PaidAmount: loan.paid_amount,
                Status: loan.status,
                DueDate: loan.due_date,
                PaidDate: loan.paid_on,
                CollectionBy: loan.collection_by,
            }));
    
            console.log('Processed Loan Data:', loanData); // Log processed data
    
            // Convert the loan data to a worksheet
            const worksheet = XLSX.utils.json_to_sheet(loanData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Loan Data");
    
            // Generate the Excel file and trigger download
            const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
            const blob = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
            saveAs(blob, `Loan_${loanId}_Data.xlsx`);
            
            console.log('Download triggered for Loan:', loanId); // Log download trigger
    
        } catch (error) {
            console.error('Error downloading Excel:', error);
            if (error.response) {
                console.error('Response data:', error.response.data); // Log additional error info
            }
        }
    };
    
    
   

    return (
        <div className="employeecontainer">
            <Sidebar 
                isSidebarExpanded={isSidebarExpanded} 
                setSidebarExpanded={setSidebarExpanded} 
            />
            <div className="main-content">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    {/* <button className="small-button" onClick={handleAdd}>Add Loan Due</button> */}
                    <div style={{ display: 'flex', alignItems: 'center', marginLeft: '10px' }}>
                        <input
                            type="text"
                            value={filterLoanId}
                            onChange={(e) => setFilterLoanId(e.target.value)}
                            placeholder="Enter Loan ID"
                            style={{ padding: '5px 10px', marginRight: '10px' }}
                        />
                        <SearchOutlined style={{ fontSize: '24px', cursor: 'pointer' }} />
                    </div>
                </div>

                <div className="table-container-loandue">
    {Object.keys(groupedLoans).length > 0 ? (
        Object.keys(groupedLoans).map(loanId => {
            // Get the first employee (or loan) associated with this loanId to retrieve customer_name
            
            return (
                <div key={loanId} className="loan-group-loandue">
                    <div className="seperate"> {/* Added a new wrapper for spacing */}
                        <div 
                            className="loan-header" 
                            onClick={() => handleToggleExpand(loanId)} 
                            style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', justifyContent: 'space-between' }}
                        >
                            <h4 style={{ margin: 0 }}>Loan ID: {loanId}</h4>
                            
                            {groupedLoans[loanId] && groupedLoans[loanId].length > 0 && (
                                <h4 style={{ margin: 0 }}>
                                    User Name: {groupedLoans[loanId][0].user_name}
                                </h4>
                            )}
                            
                            <span 
                                className={`expand-icon ${expandedLoanId === loanId ? 'rotate' : ''}`} 
                                style={{ marginLeft: '8px', color: 'white' }}
                            >
                                <DownOutlined />
                            </span>
                        </div>

                        {expandedLoanId === loanId && (
                            <div>
                                {/* Download Button above the table */}
                                <div className="download-container">
                                    <Button 
                                        onClick={() => handleDownload(loanId)} // Pass loanId to handleDownload
                                        startIcon={<DownloadIcon />} 
                                        variant="contained" 
                                        color="primary" 
                                        className="download-button"
                                    >
                                   
                                    </Button>
                                </div>

                                {/* Loan Details Table */}
                                <table className="loan-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Loan ID</th>
                                            <th>User ID</th>
                                            <th>Due Amount</th>
                                            <th>Paid Amount</th>
                                            <th>Pending Amount</th>
                                            <th>Status</th>
                                            <th>Due Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {groupedLoans[loanId].employees.map((employee, index) => {
                                            const isPending = employee.status === 'pending';
                                            const isPaid = employee.status === 'paid';
                                            const isLastDue = index === groupedLoans[loanId].employees.length - 1;
                                            const canEdit = (isLastDue && isPending) || (!isPending && !isPaid);

                                            return (
                                                <tr key={employee.id} className={isLastDue && isPending ? 'pending-loan' : ''}>
                                                    <td>{index + 1}</td>
                                                    <td>{employee.loan_id}</td>
                                                    <td>{employee.user_id}</td>
                                                    <td>{employee.next_amount||employee.due_amount }</td>
                                                    <td>{employee.paid_amount}</td>
                                                    <td>{employee.pending_amount}</td>
                                                    <td>{employee.status}</td>
                                                    <td>{new Date(employee.due_date).toLocaleDateString()}</td>
                                                    <td>
                                                        <IconButton 
                                                            onClick={() => handleEdit(employee)} 
                                                            disabled={!canEdit}
                                                        >
                                                            <EditIcon />
                                                        </IconButton>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            );
        })
    ) : (
        <p>No loans found</p>
    )}
</div>



                <Dialog open={showForm} onClose={() => setShowForm(false)}>
    <DialogTitle>{editingEmployee ? 'Edit Loan Due' : 'Add Loan Due'}</DialogTitle>
    <DialogContent style={{ backgroundColor: 'rgb(209, 241, 221)' }}>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
                <label>Loan ID:</label>
                <input
                    type="text"
                    name="loan_id"
                    value={formData.loan_id}
                    onChange={handleChange}
                    required
                    readOnly
                />
            </div>
            <div className="form-group">
                <label>User ID:</label>
                <input
                    type="text"
                    name="user_id"
                    value={formData.user_id}
                    onChange={handleChange}
                    required
                    readOnly
                />
            </div>
            <div className="form-group">
                <label>Due Amount:</label>
                <input
                    type="number"
                    name="due_amount"
                    value={formData.due_amount}
                    onChange={handleChange}
                    required
                    readOnly
                />
            </div>
            <div className="form-group">
                <label>Paid Amount:</label>
                <input
                    label="Paid Amount"
                    type="text"
                    value={formData.paid_amount}
                    // onChange={(e) => {
                    //     const paidAmount = parseFloat(e.target.value) || 0;
                    //     const dueAmount = parseFloat(formData.due_amount) || 0;

                    //     let status = 'unpaid';
                    //     if (paidAmount === dueAmount) {
                    //         status = 'paid';
                    //     } else if (paidAmount > 0 && paidAmount < dueAmount) {
                    //         status = 'pending';
                    //     }

                    //     setFormData({
                    //         ...formData,
                    //         paid_amount: e.target.value,
                    //         status: status
                    //     });
                    // }}
                    fullWidth
                    margin="normal"
                />
            </div>

            {/* Conditional Rendering for Due Date and Future Date */}
          
                <div className="form-group">
                    <label>Due Date:</label>
                    <input
                        type="date"
                        name="due_date"
                        value={formData.due_date}
                        onChange={handleChange}
                        required
                    />
                </div>
         

                <div className="form-group">
    <label>Paid On:</label>
    <input
        type="date"
        name="paid_on"
        value={formData.paid_on}
        onChange={(e) => setFormData({ ...formData, paid_on: e.target.value })}  // Update formData with paid_on
        required
    />
</div>

            <div className="form-group">
                <label>Collection By:</label>
                <input
                    type="text"
                    name="collection_by"
                    value={formData.collection_by}
                    onChange={handleChange}
                    readOnly
                />
            </div>
        </form>
    </DialogContent>
    <DialogActions>
    <Button 
        onClick={() => setShowForm(false)} 
        style={{ backgroundColor: '#3B82F6', color: 'white' }} // Medium blue color for Cancel button
    >
        Cancel
    </Button>
    <Button 
        onClick={handleSubmit} 
        style={{ backgroundColor: '#EF4444', color: 'white' }} // Medium red color for Update/Add button
    >
        {editingEmployee ? 'Update' : 'Add'}
    </Button>
</DialogActions>


</Dialog>

            </div>
             {/* Snackbar component to show the success message */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }} // Position of the snackbar
      >
        <Alert onClose={handleSnackbarClose} severity="success">
          {successMessage}
        </Alert>
      </Snackbar>
        </div>
    );
};

export default Loandue;
